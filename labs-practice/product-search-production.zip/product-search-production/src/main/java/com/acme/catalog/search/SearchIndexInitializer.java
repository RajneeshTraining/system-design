package com.acme.catalog.search;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class SearchIndexInitializer implements ApplicationRunner {
    private static final Logger log=LoggerFactory.getLogger(SearchIndexInitializer.class);
    private final RestClient client; private final String index;
    public SearchIndexInitializer(RestClient openSearchRestClient,@Value("${app.search.index}") String index) { this.client=openSearchRestClient;this.index=index; }
    @Override public void run(ApplicationArguments args) {
        try {
            var exists=client.head().uri("/{index}",index).retrieve().toBodilessEntity();
            log.info("OpenSearch index {} already exists (status {})",index,exists.getStatusCode());
        } catch(Exception notFoundOrUnavailable) {
            String mapping="""
              {"settings":{"number_of_shards":1,"number_of_replicas":0,"analysis":{"normalizer":{"folding":{"type":"custom","filter":["lowercase","asciifolding"]}}}},
               "mappings":{"dynamic":"strict","properties":{
                "id":{"type":"keyword"},"sku":{"type":"keyword"},"title":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},
                "description":{"type":"text"},"brand":{"type":"text","fields":{"keyword":{"type":"keyword","normalizer":"folding"}}},
                "category":{"type":"text","fields":{"keyword":{"type":"keyword","normalizer":"folding"}}},"color":{"type":"text","fields":{"keyword":{"type":"keyword","normalizer":"folding"}}},
                "price":{"type":"scaled_float","scaling_factor":100},"currency":{"type":"keyword"},"averageRating":{"type":"scaled_float","scaling_factor":100},
                "reviewCount":{"type":"long"},"inStock":{"type":"boolean"},"popularity":{"type":"long"},"createdAt":{"type":"date"},"updatedAt":{"type":"date"},"version":{"type":"long"}
               }}}
              """;
            try { client.put().uri("/{index}",index).header("Content-Type","application/json").body(mapping).retrieve().toBodilessEntity(); log.info("Created OpenSearch index {}",index); }
            catch(Exception ex) { log.error("Could not initialize OpenSearch index {}. Verify endpoint and credentials.",index); throw ex; }
        }
    }
}
