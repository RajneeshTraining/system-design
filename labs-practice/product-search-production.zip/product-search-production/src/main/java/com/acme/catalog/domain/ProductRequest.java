package com.acme.catalog.domain;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;

public record ProductRequest(
    @NotBlank @Size(max=100) String sku,
    @NotBlank @Size(max=300) String title,
    @Size(max=10000) String description,
    @Size(max=120) String brand,
    @Size(max=120) String category,
    @Size(max=80) String color,
    @NotNull @DecimalMin("0.00") @Digits(integer=10, fraction=2) BigDecimal price,
    @Pattern(regexp="[A-Z]{3}") String currency,
    @DecimalMin("0.0") @Digits(integer=1, fraction=2) @Max(5) BigDecimal averageRating,
    @Min(0) long reviewCount,
    boolean inStock,
    @Min(0) long popularity
) {}
