package com.acme.catalog.search;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ProductSearchService {
    private final RestClient client; private final ObjectMapper mapper; private final String index; private final int maxPage;
    public ProductSearchService(RestClient openSearchRestClient,ObjectMapper mapper,@Value("${app.search.index}") String index,@Value("${app.search.max-page-size:100}") int maxPage) { this.client=openSearchRestClient;this.mapper=mapper;this.index=index;this.maxPage=maxPage; }

    public JsonNode search(String q,String category,String brand,String color,BigDecimal minPrice,BigDecimal maxPrice,Boolean inStock,String sort,int page,int size) {
        if(page<0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"page must be >= 0");
        if(size<1||size>maxPage) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"size must be between 1 and "+maxPage);
        if(minPrice!=null&&maxPrice!=null&&minPrice.compareTo(maxPrice)>0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"minPrice must be <= maxPrice");
        ObjectNode body=mapper.createObjectNode().put("from",Math.multiplyExact(page,size)).put("size",size).put("track_total_hits",true);
        ObjectNode query=body.putObject("query"); ObjectNode bool=query.putObject("bool"); ArrayNode must=bool.putArray("must"),filter=bool.putArray("filter");
        if(q!=null&&!q.isBlank()) { ObjectNode multi=must.addObject().putObject("multi_match"); multi.put("query",q).put("fields","title^4,brand^2,description").put("fuzziness","AUTO"); }
        if(category!=null) term(filter,"category.keyword",category); if(brand!=null) term(filter,"brand.keyword",brand); if(color!=null) term(filter,"color.keyword",color); if(inStock!=null) term(filter,"inStock",inStock);
        if(minPrice!=null||maxPrice!=null) { ObjectNode range=filter.addObject().putObject("range").putObject("price"); if(minPrice!=null) range.put("gte",minPrice); if(maxPrice!=null) range.put("lte",maxPrice); }
        if(must.isEmpty()) bool.remove("must"); if(filter.isEmpty()) bool.remove("filter");
        ArrayNode sorts=body.putArray("sort");
        switch(sort==null?"relevance":sort) {
            case "price_asc" -> { sorts.addObject().putObject("price").put("order","asc"); }
            case "price_desc" -> { sorts.addObject().putObject("price").put("order","desc"); }
            case "newest" -> { sorts.addObject().putObject("createdAt").put("order","desc"); }
            case "rating" -> { sorts.addObject().putObject("averageRating").put("order","desc"); }
            case "popularity" -> { sorts.addObject().putObject("popularity").put("order","desc"); }
            case "relevance" -> { if(q==null||q.isBlank()) sorts.addObject().putObject("popularity").put("order","desc"); else sorts.addObject().putObject("_score").put("order","desc"); }
            default -> throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Unsupported sort. Use relevance, price_asc, price_desc, newest, rating, popularity");
        }
        sorts.addObject().putObject("id").put("order","asc");
        body.putObject("aggs").putObject("brands").putObject("terms").put("field","brand.keyword").put("size",30);
        body.with("aggs").putObject("categories").putObject("terms").put("field","category.keyword").put("size",30);
        body.with("aggs").putObject("colors").putObject("terms").put("field","color.keyword").put("size",30);
        try { return client.post().uri("/{index}/_search",index).body(body).retrieve().body(JsonNode.class); }
        catch(Exception e) { throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Search backend unavailable"); }
    }
    private void term(ArrayNode filter,String field,String value) { filter.addObject().putObject("term").put(field,value); }
    private void term(ArrayNode filter,String field,boolean value) { filter.addObject().putObject("term").put(field,value); }
}
