package com.acme.catalog.api;

import com.acme.catalog.domain.Product;
import com.acme.catalog.domain.ProductRequest;
import com.acme.catalog.domain.ProductService;
import com.acme.catalog.search.ProductSearchService;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.Valid;
import java.math.BigDecimal;
import java.net.URI;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/products")
public class ProductController {
    private final ProductService products; private final ProductSearchService search;
    public ProductController(ProductService products,ProductSearchService search) { this.products=products;this.search=search; }
    @PostMapping public ResponseEntity<Product> create(@Valid @RequestBody ProductRequest request) { Product p=products.create(request); return ResponseEntity.created(URI.create("/api/v1/products/"+p.id())).body(p); }
    @PutMapping("/{id}") public Product update(@PathVariable UUID id,@Valid @RequestBody ProductRequest request) { return products.update(id,request); }
    @GetMapping("/{id}") public Product get(@PathVariable UUID id) { return products.find(id); }
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable UUID id) { products.delete(id); return ResponseEntity.noContent().build(); }
    @GetMapping("/search") public JsonNode search(@RequestParam(required=false) String q,@RequestParam(required=false) String category,@RequestParam(required=false) String brand,
        @RequestParam(required=false) String color,@RequestParam(required=false) BigDecimal minPrice,@RequestParam(required=false) BigDecimal maxPrice,
        @RequestParam(required=false) Boolean inStock,@RequestParam(defaultValue="relevance") String sort,@RequestParam(defaultValue="0") int page,
        @RequestParam(defaultValue="20") int size) { return search.search(q,category,brand,color,minPrice,maxPrice,inStock,sort,page,size); }
}
