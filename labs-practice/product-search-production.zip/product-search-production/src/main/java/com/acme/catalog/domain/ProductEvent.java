package com.acme.catalog.domain;

import java.util.UUID;
public record ProductEvent(UUID eventId, String eventType, UUID productId, long version, Product product) {}
