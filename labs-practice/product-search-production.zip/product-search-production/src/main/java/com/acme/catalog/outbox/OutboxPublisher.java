package com.acme.catalog.outbox;

import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class OutboxPublisher {
    private static final Logger log=LoggerFactory.getLogger(OutboxPublisher.class);
    private final JdbcTemplate jdbc; private final KafkaTemplate<String,String> kafka;
    private final int batchSize; private final String topic;
    public OutboxPublisher(JdbcTemplate jdbc,KafkaTemplate<String,String> kafka,
       @Value("${app.outbox.batch-size:100}") int batchSize,
       @Value("${app.kafka.topic:product-events}") String topic) { this.jdbc=jdbc; this.kafka=kafka; this.batchSize=batchSize; this.topic=topic; }

    @Scheduled(fixedDelayString="${app.outbox.poll-ms:1000}")
    public void publishPending() {
        List<Row> rows=jdbc.query("SELECT id,aggregate_id,payload::text payload FROM outbox_events WHERE published_at IS NULL AND next_attempt_at<=now() ORDER BY created_at LIMIT ?",(rs,n)->new Row(rs.getObject("id",UUID.class),rs.getObject("aggregate_id",UUID.class),rs.getString("payload")),batchSize);
        for(Row row:rows) {
            try {
                kafka.send(topic,row.aggregateId().toString(),row.payload()).get();
                jdbc.update("UPDATE outbox_events SET published_at=now(),last_error=NULL WHERE id=? AND published_at IS NULL",row.id());
            } catch(Exception ex) {
                log.warn("Outbox publish failed for event {}",row.id());
                jdbc.update("UPDATE outbox_events SET attempts=attempts+1,next_attempt_at=now() + (LEAST(attempts+1,300) * interval '1 second'),last_error=? WHERE id=?",safeMessage(ex),row.id());
            }
        }
    }
    private String safeMessage(Exception e) { String s=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage()); return s.substring(0,Math.min(1000,s.length())); }
    private record Row(UUID id,UUID aggregateId,String payload) {}
}
