package com.acme.catalog.domain;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record Product(UUID id, String sku, String title, String description, String brand,
                      String category, String color, BigDecimal price, String currency,
                      BigDecimal averageRating, long reviewCount, boolean inStock,
                      long popularity, Instant createdAt, Instant updatedAt, long version) {}
