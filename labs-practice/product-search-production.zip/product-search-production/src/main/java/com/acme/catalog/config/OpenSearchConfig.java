package com.acme.catalog.config;

import java.time.Duration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

@Configuration
public class OpenSearchConfig {
    @Bean
    RestClient openSearchRestClient(@Value("${app.search.url}") String baseUrl,
                                    @Value("${app.search.connect-timeout-ms:1500}") int connectTimeout,
                                    @Value("${app.search.read-timeout-ms:2500}") int readTimeout) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(Duration.ofMillis(connectTimeout));
        factory.setReadTimeout(Duration.ofMillis(readTimeout));
        return RestClient.builder().baseUrl(baseUrl).requestFactory(factory).build();
    }
}
