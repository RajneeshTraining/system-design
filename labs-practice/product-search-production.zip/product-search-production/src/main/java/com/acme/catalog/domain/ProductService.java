package com.acme.catalog.domain;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import static org.springframework.http.HttpStatus.NOT_FOUND;

@Service
public class ProductService {
    private final JdbcTemplate jdbc; private final ObjectMapper mapper;
    public ProductService(JdbcTemplate jdbc, ObjectMapper mapper) { this.jdbc=jdbc; this.mapper=mapper; }

    @Transactional
    public Product create(ProductRequest r) {
        UUID id=UUID.randomUUID(); Instant now=Instant.now();
        jdbc.update("INSERT INTO products(id,sku,title,description,brand,category,color,price,currency,average_rating,review_count,in_stock,popularity,created_at,updated_at,version) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)",
            id,r.sku(),r.title(),r.description(),r.brand(),r.category(),r.color(),r.price(),currency(r),rating(r),r.reviewCount(),r.inStock(),r.popularity(),now,now);
        Product p=find(id); writeOutbox(p,"UPSERT"); return p;
    }
    @Transactional
    public Product update(UUID id, ProductRequest r) {
        int changed=jdbc.update("UPDATE products SET sku=?,title=?,description=?,brand=?,category=?,color=?,price=?,currency=?,average_rating=?,review_count=?,in_stock=?,popularity=?,updated_at=now(),version=version+1 WHERE id=?",
            r.sku(),r.title(),r.description(),r.brand(),r.category(),r.color(),r.price(),currency(r),rating(r),r.reviewCount(),r.inStock(),r.popularity(),id);
        if(changed==0) throw new ResponseStatusException(NOT_FOUND,"Product not found");
        Product p=find(id); writeOutbox(p,"UPSERT"); return p;
    }
    @Transactional
    public void delete(UUID id) {
        Product existing;
        try { existing=find(id); } catch(ResponseStatusException ex) { return; }
        jdbc.update("DELETE FROM products WHERE id=?",id);
        ProductEvent e=new ProductEvent(UUID.randomUUID(),"DELETE",id,existing.version()+1,null);
        outbox(e,id,"DELETE");
    }
    public Product find(UUID id) {
        List<Product> list=jdbc.query("SELECT * FROM products WHERE id=?",(rs,n)->map(rs),id);
        if(list.isEmpty()) throw new ResponseStatusException(NOT_FOUND,"Product not found"); return list.get(0);
    }
    private void writeOutbox(Product p) { writeOutbox(p,"UPSERT"); }
    private void writeOutbox(Product p,String type) { outbox(new ProductEvent(UUID.randomUUID(),type,p.id(),p.version(),p),p.id(),type); }
    private void outbox(ProductEvent e,UUID id,String type) {
        try { jdbc.update("INSERT INTO outbox_events(id,aggregate_type,aggregate_id,event_type,payload) VALUES (?,?,?,?,?::jsonb)",e.eventId(),"Product",id,type,mapper.writeValueAsString(e)); }
        catch(JsonProcessingException ex) { throw new IllegalStateException("Could not serialize outbox event",ex); }
    }
    private String currency(ProductRequest r) { return r.currency()==null ? "INR" : r.currency(); }
    private java.math.BigDecimal rating(ProductRequest r) { return r.averageRating()==null ? java.math.BigDecimal.ZERO : r.averageRating(); }
    private Product map(ResultSet rs) throws SQLException {
        return new Product(rs.getObject("id",UUID.class),rs.getString("sku"),rs.getString("title"),rs.getString("description"),rs.getString("brand"),rs.getString("category"),rs.getString("color"),rs.getBigDecimal("price"),rs.getString("currency"),rs.getBigDecimal("average_rating"),rs.getLong("review_count"),rs.getBoolean("in_stock"),rs.getLong("popularity"),rs.getTimestamp("created_at").toInstant(),rs.getTimestamp("updated_at").toInstant(),rs.getLong("version"));
    }
}
