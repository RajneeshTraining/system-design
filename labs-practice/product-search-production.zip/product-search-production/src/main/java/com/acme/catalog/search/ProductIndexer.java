package com.acme.catalog.search;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class ProductIndexer {
    private static final Logger log=LoggerFactory.getLogger(ProductIndexer.class);
    private final RestClient client; private final ObjectMapper mapper; private final String index;
    public ProductIndexer(RestClient openSearchRestClient,ObjectMapper mapper,@Value("${app.search.index}") String index) { this.client=openSearchRestClient;this.mapper=mapper;this.index=index; }
    @KafkaListener(topics="${app.kafka.topic:product-events}")
    public void consume(String raw) throws Exception {
        JsonNode event=mapper.readTree(raw); String type=event.path("eventType").asText(); String id=event.path("productId").asText(); long version=event.path("version").asLong();
        if(id.isBlank()) throw new IllegalArgumentException("Missing productId");
        if("DELETE".equals(type)) { try { client.delete().uri("/{index}/_doc/{id}",index,id).retrieve().toBodilessEntity(); } catch(Exception e) { log.debug("Delete may already be applied for {}",id); } return; }
        JsonNode product=event.path("product"); if(product.isMissingNode()||product.isNull()) throw new IllegalArgumentException("UPSERT event has no product");
        var doc=mapper.createObjectNode();
        product.fields().forEachRemaining(entry->doc.set(entry.getKey(),entry.getValue()));
        doc.put("id",id); doc.put("version",version);
        // External versioning prevents delayed duplicate events from overwriting newer indexed state.
        client.put().uri(uriBuilder->uriBuilder.path("/{index}/_doc/{id}").queryParam("version",version).queryParam("version_type","external_gte").build(Map.of("index",index,"id",id)))
            .body(doc).retrieve().toBodilessEntity();
    }
}
