CREATE TABLE products (
  id UUID PRIMARY KEY,
  sku VARCHAR(100) NOT NULL UNIQUE,
  title VARCHAR(300) NOT NULL,
  description TEXT,
  brand VARCHAR(120),
  category VARCHAR(120),
  color VARCHAR(80),
  price NUMERIC(12,2) NOT NULL CHECK (price >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  average_rating NUMERIC(3,2) NOT NULL DEFAULT 0 CHECK (average_rating >= 0 AND average_rating <= 5),
  review_count BIGINT NOT NULL DEFAULT 0 CHECK (review_count >= 0),
  in_stock BOOLEAN NOT NULL DEFAULT TRUE,
  popularity BIGINT NOT NULL DEFAULT 0 CHECK (popularity >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  version BIGINT NOT NULL DEFAULT 1
);
CREATE INDEX idx_products_category_price ON products(category, price);
CREATE INDEX idx_products_updated_at ON products(updated_at);
CREATE TABLE outbox_events (
  id UUID PRIMARY KEY,
  aggregate_type VARCHAR(100) NOT NULL,
  aggregate_id UUID NOT NULL,
  event_type VARCHAR(100) NOT NULL,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_at TIMESTAMPTZ,
  attempts INTEGER NOT NULL DEFAULT 0,
  next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_error TEXT
);
CREATE INDEX idx_outbox_pending ON outbox_events(next_attempt_at, created_at) WHERE published_at IS NULL;
