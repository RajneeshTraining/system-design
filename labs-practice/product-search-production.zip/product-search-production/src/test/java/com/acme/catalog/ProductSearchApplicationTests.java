package com.acme.catalog;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.acme.catalog.domain.ProductRequest;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

class ProductSearchApplicationTests {
    private final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

    @Test void acceptsValidProductRequest() {
        var request = new ProductRequest("SKU-1", "Running shoe", "Description", "Acme", "shoes", "black",
            new BigDecimal("99.90"), "INR", new BigDecimal("4.50"), 20, true, 100);
        assertTrue(validator.validate(request).isEmpty());
    }

    @Test void rejectsNegativePrice() {
        var request = new ProductRequest("SKU-1", "Running shoe", null, null, null, null,
            new BigDecimal("-1.00"), "INR", BigDecimal.ZERO, 0, true, 0);
        assertEquals("price", validator.validate(request).iterator().next().getPropertyPath().toString());
    }
}
