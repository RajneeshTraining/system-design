# API quick reference

All writes require HTTP Basic credentials configured with `APP_USERNAME` and `APP_PASSWORD`. Public search and `/actuator/health` are unauthenticated in this sample. Use TLS outside local development.

## Create a product

```bash
curl -u "$APP_USERNAME:$APP_PASSWORD" -H 'Content-Type: application/json' \
  -d '{"sku":"RUN-001","title":"Lightweight running shoe","description":"Daily road running shoe","brand":"Acme","category":"running-shoes","color":"black","price":3499.00,"currency":"INR","averageRating":4.4,"reviewCount":120,"inStock":true,"popularity":700}' \
  http://localhost:8080/api/v1/products
```

## Search and filter

```bash
curl 'http://localhost:8080/api/v1/products/search?q=running%20shoe&category=running-shoes&minPrice=1000&maxPrice=5000&inStock=true&sort=price_asc&page=0&size=20'
```

Supported sort values: `relevance`, `price_asc`, `price_desc`, `newest`, `rating`, `popularity`.

## Read, update, delete

```bash
curl -u "$APP_USERNAME:$APP_PASSWORD" http://localhost:8080/api/v1/products/<UUID>
curl -u "$APP_USERNAME:$APP_PASSWORD" -X PUT -H 'Content-Type: application/json' -d '{...}' http://localhost:8080/api/v1/products/<UUID>
curl -u "$APP_USERNAME:$APP_PASSWORD" -X DELETE http://localhost:8080/api/v1/products/<UUID>
```

Search response is the native OpenSearch response, including `hits` and `aggregations`. A polished public API should wrap this in a stable DTO and avoid exposing engine-specific response structure.
