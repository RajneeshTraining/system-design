# Operations guide

## SLOs to define before production

- Search API availability and p95/p99 latency.
- Index freshness: time from product transaction commit to searchable document.
- Mutation API availability and error rate.
- Outbox oldest-event age, pending count, retry count and poison-event count.
- Kafka consumer lag, indexing failure rate, OpenSearch rejection rate, shard health and disk watermarks.

## Failure playbooks

### OpenSearch unavailable
1. Confirm cluster health, disk, JVM pressure, unassigned shards, and rejected requests.
2. Keep writes flowing to PostgreSQL/outbox if database health permits.
3. Avoid retry storms: use bounded retries and circuit breaking at the API boundary.
4. Recover search, monitor consumer lag and freshness, then reconcile database versus index.

### Kafka or indexer lag
1. Inspect broker health, consumer lag and outbox backlog.
2. Check invalid event payloads, OpenSearch bulk rejections and mapping failures.
3. Replay after fixing the cause; do not silently discard events.
4. Reconcile authoritative product IDs and versions against the search index.

### Reindex
1. Create a new versioned index with reviewed mapping/settings.
2. Bulk-load a consistent catalogue snapshot while changes are captured.
3. Replay changes after the snapshot watermark.
4. Compare document counts and representative query results.
5. Atomically switch the read alias, observe, and retain the old index for rollback.

## Security checklist

- TLS for every service link; private network boundaries and network policies.
- OIDC/JWT for users and service identities; least privilege for DB, Kafka and OpenSearch.
- Secrets from a secret manager; rotate credentials; never log secrets or raw sensitive data.
- Validate query length, page size and filter counts; rate limit at gateway/WAF.
- Patch base images/dependencies; scan SBOM and images; sign images.
- Restrict actuator endpoints and OpenSearch administration to operators.
