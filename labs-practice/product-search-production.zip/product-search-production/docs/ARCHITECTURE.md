# Architecture and production design

## Data flow

```mermaid
flowchart LR
  Client --> API[Spring Boot API]
  API -->|search| OS[(OpenSearch read index)]
  API -->|transaction| PG[(PostgreSQL source of truth)]
  API -->|same transaction| OB[(Outbox table)]
  OB --> Relay[Scheduled outbox relay]
  Relay --> K[Kafka product-events]
  K --> Indexer[Kafka consumer / indexer]
  Indexer --> OS
```

## Guarantees and limitations

- PostgreSQL is authoritative. Search results are an eventually consistent read model; validate current price and inventory against PostgreSQL or the authoritative commerce service during checkout.
- Product mutations and outbox insertion commit atomically. The relay can publish duplicates if it crashes after Kafka acknowledges but before the database marks an event published. Consumers must be idempotent; upserts use external document versions.
- Outbox rows are currently polled without `FOR UPDATE SKIP LOCKED`; run one relay instance for this starter. Before horizontally scaling relay workers, implement row claiming/locking or CDC and test ordering/retry semantics.
- Deletes in this minimal example are not protected by a durable tombstone/version record in OpenSearch; delayed old upserts can recreate a deleted document. Production implementation should retain per-product versions/tombstones or use a versioned deletion strategy.
- The sample creates a single-node OpenSearch index with zero replicas. It is for local learning only, not HA.
- The demo uses HTTP Basic with one in-memory admin account. Use OIDC/JWT, managed secrets, TLS, authorization scopes, and audit logging in production.
- Search uses offset pagination for clarity. For deep pagination use PIT + `search_after` and stable sort keys.
- A production release needs retry budgets, dead-letter/replay tooling, reconciliation, index alias blue/green reindex, capacity tests, dashboards, alerting and a tested recovery plan.

## Availability target

A 99.9% monthly availability objective allows about 43.8 minutes of unavailability in a 30.4-day month. Availability is an end-to-end property: API, database, Kafka, search cluster, DNS/network, deployment, and operations all contribute. A single-node local Compose setup cannot demonstrate 99.9% availability.
