# Production-oriented E-Commerce Product Search (Java 21 + Spring Boot + OpenSearch)

A GitHub-ready reference repository that demonstrates product catalogue CRUD, a transactional PostgreSQL outbox, Kafka-based asynchronous indexing, OpenSearch search/filter/sort/facets, health endpoints, containerization, basic CI, and operational guidance.

> **Important:** This is a production-oriented learning/reference implementation, not a turnkey production deployment or a 99.9%-availability guarantee. Local Compose runs single-node dependencies with development credentials. Read `docs/ARCHITECTURE.md` and `docs/OPERATIONS.md` before adapting it to a real environment.

## Technology stack

- Java 21, Spring Boot 3.5.x, Maven
- PostgreSQL 16 + Flyway
- Apache Kafka (KRaft) for product events
- OpenSearch 2.19 for full-text search, filters, sorting and aggregations
- Docker Compose, GitHub Actions
- Spring Actuator and Spring Security HTTP Basic for the sample admin API

## Architecture

```mermaid
flowchart TB
  C[Web / Mobile] --> API[Spring Boot API]
  API -->|Search| OS[(OpenSearch)]
  API -->|CRUD transaction| DB[(PostgreSQL)]
  API --> OB[(Transactional Outbox)]
  OB --> RELAY[Outbox relay]
  RELAY --> K[Kafka]
  K --> IDX[Indexing consumer]
  IDX --> OS
```

## Quick start with Docker Compose

Requirements: Docker Engine/Desktop with Compose plugin and at least 4 GB RAM available for the stack.

```bash
# 1. Set a local-only admin password (16+ chars)
export APP_PASSWORD='local-compose-password-change-me'
# 2. Start PostgreSQL, Kafka, OpenSearch and the API
# Compose uses a documented local-only password; replace it for shared environments.
docker compose up --build -d
# 3. Check health
docker compose ps
curl -fsS http://localhost:8080/actuator/health
```

The compose app password is explicitly for local development. Do not expose these ports to the public internet. OpenSearch security is disabled in Compose for convenience.

## Run app outside Docker

Start PostgreSQL, Kafka and OpenSearch separately, then set environment variables:

```bash
export DB_URL='jdbc:postgresql://localhost:5432/catalog'
export DB_USERNAME='catalog'
export DB_PASSWORD='your-local-db-password'
export KAFKA_BOOTSTRAP_SERVERS='localhost:9092'
export OPENSEARCH_URL='http://localhost:9200'
export APP_USERNAME='catalog-admin'
export APP_PASSWORD='a-unique-password-at-least-16-chars'
mvn spring-boot:run
```

## API examples

See [`docs/API.md`](docs/API.md). Search is public in this sample; product writes require Basic authentication. Example:

```bash
curl 'http://localhost:8080/api/v1/products/search?q=running&sort=price_asc&page=0&size=20'
```

## Build and test

```bash
mvn -B clean verify
```

The included tests validate request constraints without requiring running infrastructure. For CI-grade integration coverage, add Testcontainers for PostgreSQL and an isolated OpenSearch/Kafka test setup, then add end-to-end tests for outbox delivery, indexing, and search semantics.

## Configuration reference

| Variable | Purpose | Local default |
|---|---|---|
| `DB_URL` | JDBC URL | `jdbc:postgresql://localhost:5432/catalog` |
| `DB_USERNAME` / `DB_PASSWORD` | PostgreSQL credentials | local-only values |
| `KAFKA_BOOTSTRAP_SERVERS` | Kafka brokers | `localhost:9092` |
| `OPENSEARCH_URL` | OpenSearch endpoint | `http://localhost:9200` |
| `OPENSEARCH_INDEX` | Search index name | `products-v1` |
| `APP_USERNAME` / `APP_PASSWORD` | Sample admin account | must be set securely |
| `OUTBOX_POLL_MS` | Outbox polling delay | `1000` |

## Before production

- Replace sample HTTP Basic auth with OIDC/JWT and service identities.
- Enable TLS/authentication for PostgreSQL, Kafka and OpenSearch; use secrets manager.
- Deploy multi-AZ database, Kafka and OpenSearch with replicas and tested backups.
- Implement safe multi-worker outbox claiming/CDC, tombstones for deletes, DLQ/replay and reconciliation.
- Use PIT + `search_after` for deep pagination and versioned index aliases for zero-downtime reindex.
- Add Testcontainers, contract tests, load tests, security scans, SLO dashboards and alert runbooks.
- Set shard/replica counts from representative benchmarks. Do not use local Compose topology for HA claims.

## Repository layout

```text
src/main/java/com/acme/catalog/
  api/        REST controllers and error handling
  config/     OpenSearch HTTP client and security configuration
  domain/     Product model, request validation and transactional CRUD/outbox writes
  outbox/     Outbox-to-Kafka relay
  search/     OpenSearch query service, indexer and mapping bootstrap
src/main/resources/db/migration/  Flyway schema
src/test/    Tests
 docs/       Architecture, API and operations
 deploy/k8s/ Production deployment considerations
 .github/workflows/ci.yml  Maven CI
```

## License

MIT; see `LICENSE`.
