#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${BASE_URL:-http://localhost:8080}"
curl --fail --silent --show-error "$BASE_URL/actuator/health"
printf '\nSearch endpoint:\n'
curl --fail --silent --show-error "$BASE_URL/api/v1/products/search?sort=popularity&page=0&size=5"
printf '\n'
