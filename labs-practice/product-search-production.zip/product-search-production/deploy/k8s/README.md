# Kubernetes deployment notes

This repository intentionally does not ship a copy-paste production manifest with hard-coded credentials. In a real cluster:

1. Deploy PostgreSQL, Kafka, and OpenSearch using managed services or their supported operators/charts, with multi-AZ durability and TLS.
2. Build and scan the image, push it to a private registry, and pin it by immutable digest.
3. Create Kubernetes Secrets from an external secret manager; never commit them.
4. Set `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `KAFKA_BOOTSTRAP_SERVERS`, `OPENSEARCH_URL`, `APP_USERNAME`, and `APP_PASSWORD`.
5. Add readiness/liveness probes to `/actuator/health/readiness` and `/actuator/health/liveness`, CPU/memory requests and limits, PodDisruptionBudget, topology spread, NetworkPolicies, autoscaling, and ingress TLS.
6. Use a dedicated least-privilege OpenSearch role, Kafka ACLs, database role grants, and external identity/OIDC instead of this sample's in-memory HTTP Basic user.
7. Configure OpenSearch replicas and shard counts based on load tests; local Compose intentionally uses one node and zero replicas.

A production release requires environment-specific manifests, secret management, policy review, load testing, and disaster-recovery validation.
