# API contracts

All endpoints are prefixed with `/api/v1`. The current proof of concept uses `X-User-Id` as a development-only caller identity header. Do not expose this behavior to untrusted networks.

## Create direct conversation

`POST /conversations/direct`

Request: `{"participantId":"bob"}`

Headers: `X-User-Id: alice`, `Content-Type: application/json`

Response: `201 Created`, `ConversationResponse`.

## Get conversation

`GET /conversations/{conversationId}`

Headers: `X-User-Id: alice`

Response: `200 OK`, `ConversationResponse` if caller is a member.

## Send message

`POST /conversations/{conversationId}/messages`

Headers: `X-User-Id: alice`, `Idempotency-Key: client-generated-key`, `Content-Type: application/json`

Request: `{"body":"Hello"}`

Response: `200 OK`, `MessageResponse`. The idempotency key should be unique per logical send attempt and reused for retries of that same attempt.

## List messages

`GET /conversations/{conversationId}/messages?limit=50&beforeSequence=9223372036854775807`

Headers: `X-User-Id: alice`

Response: `200 OK`, array of `MessageResponse`, newest-first. Use a sequence from the last item to fetch the next older page.
