# Architecture notes

```mermaid
flowchart LR
  Client[Mobile / API client] -->|REST + development identity header| API[Spring Boot API]
  API --> DB[(PostgreSQL)]
  DB -->|same transaction| Outbox[Outbox event row]
  Publisher[Scheduled outbox publisher] --> DB
  Publisher --> Kafka[(Kafka: message-created)]
  API -. future cache / presence .-> Redis[(Redis)]
```

## Message submission transaction

1. Check that the caller is a member of the conversation.
2. Look up `(sender_id, idempotency_key)` to make client retries safe.
3. Lock the conversation row with `SELECT ... FOR UPDATE` semantics and allocate the next sequence.
4. Insert the message and outbox event in one PostgreSQL transaction.
5. A scheduled publisher sends pending outbox rows to Kafka and marks successful rows as published.

The outbox closes the database-commit/Kafka-publish dual-write gap, but it does not make publication exactly-once. A crash after Kafka acknowledges and before the database marks the event published can lead to duplicate events. Consumers should be idempotent, usually by recording processed event IDs in the same transaction as their side effect.

## Scaling notes

- The conversation row lock gives simple, correct sequence allocation but serializes writes within one conversation. This is a reasonable PoC tradeoff; profile hot conversations before changing it.
- A single-node local Kafka broker and a single PostgreSQL instance are for development only.
- Redis is present in Compose but is not yet used by the API. Suitable future uses include ephemeral presence, typing indicators, rate-limit counters, and connection routing hints—not the durable source of message history.
- Message bodies are stored as plaintext in this PoC. End-to-end encryption needs a client-side protocol, identity/key verification, multi-device key management, and security review.
