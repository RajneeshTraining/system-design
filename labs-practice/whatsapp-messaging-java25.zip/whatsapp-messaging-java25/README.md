# WhatsApp-like Messaging Backend — Java 25 + Spring Boot

A small, runnable backend proof of concept for the core durable-message flow. It is intended for learning, system-design interviews, and as a starting point for further engineering—not as a production-ready WhatsApp clone.

## Implemented in this repository

- Java 25, Maven, Spring Boot 3.5.7
- REST API for direct conversation creation, conversation lookup, message submission, and paginated history
- PostgreSQL persistence with Flyway migrations
- Conversation membership checks
- Per-conversation sequence allocation protected by a PostgreSQL row lock
- `Idempotency-Key` handling for safe client retries
- Transactional outbox: message and event are committed in the same database transaction
- Scheduled outbox publisher to Kafka topic `message-created` (at-least-once delivery; consumers must be idempotent)
- Redis included in local infrastructure as an extension point; this PoC does not yet use Redis in request handling
- Actuator health, info, and metrics endpoints
- Docker Compose for PostgreSQL, Redis, and single-node Kafka in KRaft mode

## Explicit PoC limitations

This is not a complete chat platform and should not be represented as production-ready. The `X-User-Id` header is a **development-only identity stub**, not authentication. Message `body` is plaintext—not end-to-end encrypted. This version does not implement user registration/login, device sessions, group chat, WebSocket delivery, delivery/read receipts, media, push notifications, rate limiting, abuse controls, or a Kafka consumer. Kafka and Redis are local single-node services here. Before production use, add real identity and authorization, TLS, secrets management, threat modelling, encryption design, consumer idempotency, observability, load tests, backups, and multi-zone deployment.

## Prerequisites

- JDK 25 (`java -version` should report 25)
- Maven 3.9+
- Docker Engine and Docker Compose v2
- `curl` (or Postman/Insomnia)

## 1. Start infrastructure

From the repository root:

```bash
docker compose up -d
 docker compose ps
```

The compose file exposes PostgreSQL on `localhost:5432`, Redis on `localhost:6379`, and Kafka on `localhost:9092`. The credentials are intentionally simple local-development credentials; do not reuse them outside a local environment.

Wait for PostgreSQL to become healthy before starting the app:

```bash
docker compose ps
```

## 2. Build and test

```bash
mvn clean verify
```

The build is configured to compile with Java release 25. If your default Java is not 25, set `JAVA_HOME` and update `PATH` before running Maven. No Maven Wrapper is included in this version; use an installed Maven 3.9+.

## 3. Run the API

```bash
mvn spring-boot:run
```

Or build and run the JAR:

```bash
mvn clean package
java -jar target/whatsapp-messaging-java25-0.1.0-SNAPSHOT.jar
```

Default API base URL: `http://localhost:8080`.

Health check:

```bash
curl -i http://localhost:8080/actuator/health
```

## 4. Validate the API end to end

### 4.1 Create a direct conversation

The `X-User-Id` header simulates the authenticated caller for local testing only.

```bash
curl -sS -X POST http://localhost:8080/api/v1/conversations/direct \
  -H 'Content-Type: application/json' \
  -H 'X-User-Id: alice' \
  -d '{"participantId":"bob"}'
```

Example response (IDs and timestamps are generated):

```json
{
  "id": "<conversation-uuid>",
  "type": "DIRECT",
  "members": ["alice", "bob"],
  "createdAt": "2026-10-23T12:00:00Z"
}
```

Copy the returned `id` into `CONVERSATION_ID` in the examples below. This API creates a new conversation on every request; deduplication of direct conversations is not implemented.

### 4.2 Send a message

```bash
export CONVERSATION_ID='<conversation-uuid>'

curl -sS -X POST "http://localhost:8080/api/v1/conversations/${CONVERSATION_ID}/messages" \
  -H 'Content-Type: application/json' \
  -H 'X-User-Id: alice' \
  -H 'Idempotency-Key: alice-msg-0001' \
  -d '{"body":"Hello Bob!"}'
```

The response includes the message ID, conversation ID, sender, sequence number, body, and creation timestamp. Repeat the exact request with the same sender and idempotency key to receive the same logical message instead of creating another one. Reusing the key with a different body or conversation returns HTTP 400.

### 4.3 Read message history

```bash
curl -sS "http://localhost:8080/api/v1/conversations/${CONVERSATION_ID}/messages?limit=50" \
  -H 'X-User-Id: bob'
```

History is returned newest-first by sequence number. To fetch older messages, pass `beforeSequence` using the lowest sequence number from the current page:

```bash
curl -sS "http://localhost:8080/api/v1/conversations/${CONVERSATION_ID}/messages?beforeSequence=2&limit=50" \
  -H 'X-User-Id: bob'
```

### 4.4 Fetch conversation details

```bash
curl -sS "http://localhost:8080/api/v1/conversations/${CONVERSATION_ID}" \
  -H 'X-User-Id: alice'
```

Only a conversation member can read its details or message history, or send a message to it.

## 5. API reference

| Method | Endpoint | Required headers | Purpose |
|---|---|---|---|
| `POST` | `/api/v1/conversations/direct` | `X-User-Id` | Create a direct conversation with `{"participantId":"bob"}` |
| `GET` | `/api/v1/conversations/{conversationId}` | `X-User-Id` | Get conversation details and member IDs |
| `POST` | `/api/v1/conversations/{conversationId}/messages` | `X-User-Id`, `Idempotency-Key` | Submit a text message with `{"body":"..."}` |
| `GET` | `/api/v1/conversations/{conversationId}/messages?limit=50&beforeSequence=...` | `X-User-Id` | Read paginated history |
| `GET` | `/actuator/health` | none | Liveness/readiness-style health information |
| `GET` | `/actuator/metrics` | none | Actuator metric index |

Error response shape:

```json
{"code":"FORBIDDEN","message":"User is not a member of this conversation","timestamp":"2026-10-23T12:00:00Z"}
```

Common statuses: `400` invalid request or idempotency-key conflict, `403` non-member, `404` unknown conversation, `500` unexpected server error.

## 6. Verify Kafka publication

The outbox publisher emits JSON payloads to `message-created`, using the conversation UUID as the Kafka key to keep events for a conversation on the same partition. Since a process can fail after Kafka accepts an event but before `published_at` commits, publication is **at least once**. Any consumer must deduplicate events.

Using the Kafka container, consume from the beginning:

```bash
docker compose exec kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list
docker compose exec kafka /opt/kafka/bin/kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 --topic message-created --from-beginning
```

Send another message from section 4.2 and observe the JSON event in the consumer output. The topic is created automatically by Kafka's local auto-topic-creation configuration; for stricter environments, provision topics explicitly with the desired partition and replication settings.

## 7. Database schema

Flyway migration: `src/main/resources/db/migration/V1__initial_schema.sql`.

- `conversations`: conversation metadata and next sequence counter
- `conversation_members`: membership and role
- `messages`: durable messages, unique idempotency key per sender, unique sequence per conversation
- `outbox_events`: durable events awaiting Kafka publication

Hibernate schema auto-generation is disabled (`ddl-auto: validate`); Flyway owns schema changes.

## 8. Configuration

The defaults are suitable only for local development. Override these environment variables as needed:

| Variable | Default |
|---|---|
| `SPRING_DATASOURCE_URL` | `jdbc:postgresql://localhost:5432/messaging` |
| `SPRING_DATASOURCE_USERNAME` | `messaging` |
| `SPRING_DATASOURCE_PASSWORD` | `messaging_dev_only` |
| `KAFKA_BOOTSTRAP_SERVERS` | `localhost:9092` |
| `REDIS_HOST` / `REDIS_PORT` | `localhost` / `6379` |
| `DB_POOL_SIZE` | `20` |
| `OUTBOX_POLL_DELAY_MS` | `1000` |
| `SERVER_PORT` | `8080` |

## 9. Troubleshooting

- **App cannot connect to PostgreSQL:** run `docker compose ps`, inspect `docker compose logs postgres`, and verify the datasource environment variables.
- **Flyway or Hibernate schema error:** ensure a clean local database or inspect migration history. Do not manually change the schema without a new migration.
- **Kafka events not appearing:** inspect `docker compose logs kafka` and application logs; verify `KAFKA_BOOTSTRAP_SERVERS` is reachable from the app process.
- **Port already in use:** change published ports in `compose.yaml` and the matching datasource/bootstrap environment values.
- **Build fails with invalid target release:** the Maven process is using a JDK older than 25. Check `java -version`, `mvn -version`, `JAVA_HOME`, and `PATH`.

Stop local infrastructure with `docker compose down`; remove local data volumes with `docker compose down -v` (destructive).

## 10. Suggested next implementation increments

1. Replace `X-User-Id` with Spring Security and OAuth 2.1/OIDC JWT validation.
2. Add a real user/device model and direct-conversation deduplication.
3. Add Kafka consumer(s) with idempotent inbox/consumer-offset handling and retry/DLQ policy.
4. Add WebSocket/STOMP or a purpose-built WebSocket gateway and per-device delivery queues.
5. Add delivery/read receipts, groups, block/report controls, and rate limits.
6. Define a reviewed E2EE protocol and client key lifecycle; never invent cryptography.
7. Add Testcontainers integration tests, contract tests, load tests, dashboards, alerts, backup/restore drills, and multi-zone deployment.

## License

Provided as an educational starter. Add your preferred license before publishing or distributing it as an open-source project.
