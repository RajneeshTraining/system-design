CREATE TABLE conversations (
    id UUID PRIMARY KEY,
    conversation_type VARCHAR(16) NOT NULL,
    title VARCHAR(200) NOT NULL DEFAULT '',
    next_sequence BIGINT NOT NULL DEFAULT 1 CHECK (next_sequence > 0),
    created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE conversation_members (
    id UUID PRIMARY KEY,
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    user_id VARCHAR(128) NOT NULL,
    role VARCHAR(16) NOT NULL DEFAULT 'MEMBER',
    joined_at TIMESTAMPTZ NOT NULL,
    CONSTRAINT uq_conversation_member UNIQUE (conversation_id, user_id)
);
CREATE INDEX idx_conversation_members_user ON conversation_members(user_id, conversation_id);

CREATE TABLE messages (
    id UUID PRIMARY KEY,
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_id VARCHAR(128) NOT NULL,
    idempotency_key VARCHAR(128) NOT NULL,
    sequence_number BIGINT NOT NULL,
    body VARCHAR(4000) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    CONSTRAINT uq_message_idempotency UNIQUE (sender_id, idempotency_key),
    CONSTRAINT uq_message_sequence UNIQUE (conversation_id, sequence_number)
);
CREATE INDEX idx_messages_conversation_sequence ON messages(conversation_id, sequence_number DESC);

CREATE TABLE outbox_events (
    id UUID PRIMARY KEY,
    aggregate_id UUID NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    payload TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    published_at TIMESTAMPTZ
);
CREATE INDEX idx_outbox_published_created ON outbox_events(published_at, created_at);
