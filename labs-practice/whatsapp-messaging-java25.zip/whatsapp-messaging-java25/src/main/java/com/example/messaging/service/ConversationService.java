package com.example.messaging.service;

import com.example.messaging.api.ApiModels;
import com.example.messaging.domain.Conversation;
import com.example.messaging.domain.ConversationMember;
import com.example.messaging.repository.ConversationMemberRepository;
import com.example.messaging.repository.ConversationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.UUID;

@Service
public class ConversationService {
    private final ConversationRepository conversations;
    private final ConversationMemberRepository members;
    public ConversationService(ConversationRepository conversations, ConversationMemberRepository members) {
        this.conversations = conversations; this.members = members;
    }

    @Transactional
    public ApiModels.ConversationResponse createDirect(String creatorId, String participantId) {
        if (creatorId.equals(participantId)) throw new IllegalArgumentException("A direct conversation requires two different users");
        Conversation conversation = conversations.save(new Conversation("DIRECT", ""));
        members.save(new ConversationMember(conversation.getId(), creatorId, "MEMBER"));
        members.save(new ConversationMember(conversation.getId(), participantId, "MEMBER"));
        return new ApiModels.ConversationResponse(conversation.getId(), conversation.getType(), List.of(creatorId, participantId), conversation.getCreatedAt());
    }

    @Transactional(readOnly = true)
    public void assertMember(UUID conversationId, String userId) {
        if (!conversations.existsById(conversationId)) throw new ResourceNotFoundException("Conversation not found");
        if (!members.existsByConversationIdAndUserId(conversationId, userId)) throw new ForbiddenOperationException("User is not a member of this conversation");
    }

    @Transactional(readOnly = true)
    public ApiModels.ConversationResponse getConversation(UUID id, String userId) {
        assertMember(id, userId);
        Conversation conversation = conversations.findById(id).orElseThrow(() -> new ResourceNotFoundException("Conversation not found"));
        List<String> memberIds = members.findByConversationId(id).stream().map(ConversationMember::getUserId).toList();
        return new ApiModels.ConversationResponse(conversation.getId(), conversation.getType(), memberIds, conversation.getCreatedAt());
    }
}
