package com.example.messaging.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "conversation_members", uniqueConstraints = @UniqueConstraint(name = "uq_conversation_member", columnNames = {"conversation_id", "user_id"}))
public class ConversationMember {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @Column(name = "conversation_id", nullable = false)
    private UUID conversationId;
    @Column(name = "user_id", nullable = false, length = 128)
    private String userId;
    @Column(nullable = false, length = 16)
    private String role = "MEMBER";
    @Column(name = "joined_at", nullable = false)
    private Instant joinedAt = Instant.now();
    protected ConversationMember() {}
    public ConversationMember(UUID conversationId, String userId, String role) { this.conversationId = conversationId; this.userId = userId; this.role = role; }
    public UUID getId() { return id; }
    public UUID getConversationId() { return conversationId; }
    public String getUserId() { return userId; }
    public String getRole() { return role; }
    public Instant getJoinedAt() { return joinedAt; }
}
