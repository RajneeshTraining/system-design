package com.example.messaging.repository;

import com.example.messaging.domain.ChatMessage;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, UUID> {
    Optional<ChatMessage> findBySenderIdAndIdempotencyKey(String senderId, String idempotencyKey);
    List<ChatMessage> findByConversationIdAndSequenceNumberLessThanOrderBySequenceNumberDesc(UUID conversationId, long beforeSequence, Pageable pageable);
}
