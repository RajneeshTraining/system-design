package com.example.messaging.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "conversations")
public class Conversation {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @Column(name = "conversation_type", nullable = false, length = 16)
    private String type = "DIRECT";
    @Column(nullable = false, length = 200)
    private String title = "";
    @Column(name = "next_sequence", nullable = false)
    private long nextSequence = 1;
    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();

    protected Conversation() {}
    public Conversation(String type, String title) { this.type = type; this.title = title == null ? "" : title; }
    public long allocateSequence() { return nextSequence++; }
    public UUID getId() { return id; }
    public String getType() { return type; }
    public String getTitle() { return title; }
    public long getNextSequence() { return nextSequence; }
    public Instant getCreatedAt() { return createdAt; }
}
