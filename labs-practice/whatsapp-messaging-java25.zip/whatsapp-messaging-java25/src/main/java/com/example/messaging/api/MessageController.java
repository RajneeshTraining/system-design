package com.example.messaging.api;

import com.example.messaging.service.MessageService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.UUID;

@RestController
@Validated
@RequestMapping("/api/v1/conversations/{conversationId}/messages")
public class MessageController {
    private final MessageService service;
    public MessageController(MessageService service) { this.service = service; }

    @PostMapping
    public ApiModels.MessageResponse send(@RequestHeader("X-User-Id") String userId,
                                         @RequestHeader("Idempotency-Key") String idempotencyKey,
                                         @PathVariable UUID conversationId,
                                         @Valid @RequestBody ApiModels.SendMessageRequest request) {
        if (idempotencyKey.isBlank() || idempotencyKey.length() > 128) throw new IllegalArgumentException("Idempotency-Key must be 1-128 characters");
        return service.send(conversationId, userId, idempotencyKey, request.body());
    }

    @GetMapping
    public List<ApiModels.MessageResponse> history(@RequestHeader("X-User-Id") String userId,
                                                   @PathVariable UUID conversationId,
                                                   @RequestParam(defaultValue = "9223372036854775807") long beforeSequence,
                                                   @RequestParam(defaultValue = "50") @Min(1) @Max(100) int limit) {
        return service.history(conversationId, userId, beforeSequence, limit);
    }
}
