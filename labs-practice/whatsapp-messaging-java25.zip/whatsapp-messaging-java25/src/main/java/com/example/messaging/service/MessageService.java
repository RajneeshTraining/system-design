package com.example.messaging.service;

import com.example.messaging.api.ApiModels;
import com.example.messaging.domain.ChatMessage;
import com.example.messaging.domain.Conversation;
import com.example.messaging.domain.OutboxEvent;
import com.example.messaging.repository.ChatMessageRepository;
import com.example.messaging.repository.ConversationMemberRepository;
import com.example.messaging.repository.ConversationRepository;
import com.example.messaging.repository.OutboxEventRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.UUID;

@Service
public class MessageService {
    private final ConversationRepository conversations;
    private final ConversationMemberRepository members;
    private final ChatMessageRepository messages;
    private final OutboxEventRepository outbox;
    private final ObjectMapper objectMapper;

    public MessageService(ConversationRepository conversations, ConversationMemberRepository members, ChatMessageRepository messages,
                          OutboxEventRepository outbox, ObjectMapper objectMapper) {
        this.conversations = conversations; this.members = members; this.messages = messages; this.outbox = outbox; this.objectMapper = objectMapper;
    }

    @Transactional
    public ApiModels.MessageResponse send(UUID conversationId, String senderId, String idempotencyKey, String body) {
        if (!members.existsByConversationIdAndUserId(conversationId, senderId)) {
            if (!conversations.existsById(conversationId)) throw new ResourceNotFoundException("Conversation not found");
            throw new ForbiddenOperationException("User is not a member of this conversation");
        }
        var previous = messages.findBySenderIdAndIdempotencyKey(senderId, idempotencyKey);
        if (previous.isPresent()) {
            ChatMessage existing = previous.get();
            if (!existing.getConversationId().equals(conversationId) || !existing.getBody().equals(body)) {
                throw new IllegalArgumentException("Idempotency key was already used for a different request");
            }
            return toResponse(existing);
        }
        Conversation conversation = conversations.findByIdForUpdate(conversationId).orElseThrow(() -> new ResourceNotFoundException("Conversation not found"));
        long sequence = conversation.allocateSequence();
        ChatMessage message = messages.save(new ChatMessage(conversationId, senderId, idempotencyKey, sequence, body));
        try {
            String payload = objectMapper.writeValueAsString(toResponse(message));
            outbox.save(new OutboxEvent(message.getConversationId(), "MESSAGE_CREATED", payload));
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Could not serialize message event", e);
        }
        return toResponse(message);
    }

    @Transactional(readOnly = true)
    public List<ApiModels.MessageResponse> history(UUID conversationId, String userId, long beforeSequence, int limit) {
        if (!members.existsByConversationIdAndUserId(conversationId, userId)) {
            if (!conversations.existsById(conversationId)) throw new ResourceNotFoundException("Conversation not found");
            throw new ForbiddenOperationException("User is not a member of this conversation");
        }
        return messages.findByConversationIdAndSequenceNumberLessThanOrderBySequenceNumberDesc(conversationId, beforeSequence, PageRequest.of(0, limit))
                .stream().map(MessageService::toResponse).toList();
    }
    private static ApiModels.MessageResponse toResponse(ChatMessage m) {
        return new ApiModels.MessageResponse(m.getId(), m.getConversationId(), m.getSenderId(), m.getSequenceNumber(), m.getBody(), m.getCreatedAt());
    }
}
