package com.example.messaging.service;

import com.example.messaging.domain.OutboxEvent;
import com.example.messaging.repository.OutboxEventRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.util.concurrent.TimeUnit;

@Component
public class OutboxPublisher {
    private static final Logger log = LoggerFactory.getLogger(OutboxPublisher.class);
    private final OutboxEventRepository repository;
    private final KafkaTemplate<String, String> kafkaTemplate;
    public OutboxPublisher(OutboxEventRepository repository, KafkaTemplate<String, String> kafkaTemplate) {
        this.repository = repository; this.kafkaTemplate = kafkaTemplate;
    }

    @Scheduled(fixedDelayString = "${messaging.outbox.poll-delay-ms:1000}")
    @Transactional
    public void publishPending() {
        for (OutboxEvent event : repository.findTop100ByPublishedAtIsNullOrderByCreatedAtAsc()) {
            try {
                kafkaTemplate.send("message-created", event.getAggregateId().toString(), event.getPayload()).get(3, TimeUnit.SECONDS);
                event.markPublished();
            } catch (Exception e) {
                log.warn("Outbox event {} could not be published; it will be retried", event.getId(), e);
                break;
            }
        }
    }
}
