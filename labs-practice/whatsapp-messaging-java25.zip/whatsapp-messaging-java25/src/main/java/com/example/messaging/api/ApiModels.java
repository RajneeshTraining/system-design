package com.example.messaging.api;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public final class ApiModels {
    private ApiModels() {}
    public record CreateDirectConversationRequest(@NotBlank @Size(max = 128) String participantId) {}
    public record ConversationResponse(UUID id, String type, List<String> members, Instant createdAt) {}
    public record SendMessageRequest(@NotBlank @Size(max = 4000) String body) {}
    public record MessageResponse(UUID id, UUID conversationId, String senderId, long sequenceNumber, String body, Instant createdAt) {}
    public record ErrorResponse(String code, String message, Instant timestamp) {}
}
