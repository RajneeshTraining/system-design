package com.example.messaging.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "messages", uniqueConstraints = @UniqueConstraint(name = "uq_message_idempotency", columnNames = {"sender_id", "idempotency_key"}), indexes = {
    @Index(name = "idx_messages_conversation_sequence", columnList = "conversation_id,sequence_number")
})
public class ChatMessage {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @Column(name = "conversation_id", nullable = false)
    private UUID conversationId;
    @Column(name = "sender_id", nullable = false, length = 128)
    private String senderId;
    @Column(name = "idempotency_key", nullable = false, length = 128)
    private String idempotencyKey;
    @Column(name = "sequence_number", nullable = false)
    private long sequenceNumber;
    @Column(name = "body", nullable = false, length = 4000)
    private String body;
    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();
    protected ChatMessage() {}
    public ChatMessage(UUID conversationId, String senderId, String idempotencyKey, long sequenceNumber, String body) {
        this.conversationId = conversationId; this.senderId = senderId; this.idempotencyKey = idempotencyKey; this.sequenceNumber = sequenceNumber; this.body = body;
    }
    public UUID getId() { return id; }
    public UUID getConversationId() { return conversationId; }
    public String getSenderId() { return senderId; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public long getSequenceNumber() { return sequenceNumber; }
    public String getBody() { return body; }
    public Instant getCreatedAt() { return createdAt; }
}
