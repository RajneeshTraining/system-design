package com.example.messaging.api;

import com.example.messaging.service.ForbiddenOperationException;
import com.example.messaging.service.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import jakarta.validation.ConstraintViolationException;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.time.Instant;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiModels.ErrorResponse> notFound(ResourceNotFoundException e) { return response(HttpStatus.NOT_FOUND, "NOT_FOUND", e.getMessage()); }
    @ExceptionHandler(ForbiddenOperationException.class)
    public ResponseEntity<ApiModels.ErrorResponse> forbidden(ForbiddenOperationException e) { return response(HttpStatus.FORBIDDEN, "FORBIDDEN", e.getMessage()); }
    @ExceptionHandler({IllegalArgumentException.class, MethodArgumentNotValidException.class, HttpMessageNotReadableException.class, MissingRequestHeaderException.class, MethodArgumentTypeMismatchException.class, ConstraintViolationException.class})
    public ResponseEntity<ApiModels.ErrorResponse> badRequest(Exception e) {
        String message = e instanceof MethodArgumentNotValidException ? "Request validation failed" : e.getMessage();
        return response(HttpStatus.BAD_REQUEST, "BAD_REQUEST", message == null ? "Invalid request" : message);
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiModels.ErrorResponse> internal(Exception e) { return response(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR", "An unexpected error occurred"); }
    private ResponseEntity<ApiModels.ErrorResponse> response(HttpStatus status, String code, String message) {
        return ResponseEntity.status(status).body(new ApiModels.ErrorResponse(code, message, Instant.now()));
    }
}
