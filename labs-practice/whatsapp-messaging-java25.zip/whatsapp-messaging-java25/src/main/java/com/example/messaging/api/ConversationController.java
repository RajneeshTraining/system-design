package com.example.messaging.api;

import com.example.messaging.service.ConversationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/conversations")
public class ConversationController {
    private final ConversationService service;
    public ConversationController(ConversationService service) { this.service = service; }

    @PostMapping("/direct")
    @ResponseStatus(HttpStatus.CREATED)
    public ApiModels.ConversationResponse createDirect(@RequestHeader("X-User-Id") String userId,
                                                       @Valid @RequestBody ApiModels.CreateDirectConversationRequest request) {
        return service.createDirect(userId, request.participantId());
    }

    @GetMapping("/{conversationId}")
    public ApiModels.ConversationResponse get(@RequestHeader("X-User-Id") String userId, @PathVariable UUID conversationId) {
        return service.getConversation(conversationId, userId);
    }
}
