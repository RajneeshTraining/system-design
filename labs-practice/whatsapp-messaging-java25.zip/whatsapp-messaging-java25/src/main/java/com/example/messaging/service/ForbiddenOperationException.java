package com.example.messaging.service;
public class ForbiddenOperationException extends RuntimeException { public ForbiddenOperationException(String message) { super(message); } }
