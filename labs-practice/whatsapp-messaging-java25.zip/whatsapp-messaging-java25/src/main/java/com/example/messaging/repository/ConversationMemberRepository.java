package com.example.messaging.repository;

import com.example.messaging.domain.ConversationMember;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface ConversationMemberRepository extends JpaRepository<ConversationMember, UUID> {
    boolean existsByConversationIdAndUserId(UUID conversationId, String userId);
    List<ConversationMember> findByConversationId(UUID conversationId);
}
