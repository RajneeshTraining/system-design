package com.example.messaging;

import com.example.messaging.domain.Conversation;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ConversationSequenceTest {
    @Test
    void allocatesIncreasingSequenceNumbers() {
        Conversation conversation = new Conversation("DIRECT", "");
        assertEquals(1L, conversation.allocateSequence());
        assertEquals(2L, conversation.allocateSequence());
        assertEquals(3L, conversation.allocateSequence());
    }
}
